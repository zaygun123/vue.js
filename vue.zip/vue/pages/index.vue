<template>
<div class="main-page d-flex">
   <CharactersCard v-for="character in characters" :key="character.name" :character="character"/>
</div>
  
</template>

<script>
import axios from 'axios'
import CharactersCard from '../components/CharactersCard.vue'
 export default{
    name: "IndexPage",
    data() {
        return {
            characters: []
        };
    },
    created() {
        this.getAllUser();
    },
    methods: {
        getAllUser() {
            axios.get("https://pokeapi.co/api/v2/pokemon").then((response) => {
                console.log(response);
            });
        }
    },
    components: { CharactersCard }
}
</script>

<style>
.main-page{
  flex-wrap: wrap;
}
.card{
    margin-top: 30px;
    background: yellow;
    width: 400px;
    height: 400px;
    text-align: center;
    padding: 20px;
    border-radius: 6px;
    border:10px blue solid;
    box-shadow: 1px 2px 4px rgba(0,0,0,0.5);
    }
</style>

