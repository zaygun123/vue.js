<template>
 <div class="card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title">{{character.name}}</h5>
      <img src="character.sprites.other.home.front_default"  style="width:200px">
   
  </div>
</div>

</template>

<script>
export default {
  name: 'UserCard',
  props: {
    product: {
      type: Object,
      default: null
    }
  }
}
</script>
<style>
.card{
    margin-top: 30px;
    background: yellow;
    width: 400px;
    height: 400px;
    text-align: center;
    padding: 20px;
    border-radius: 6px;
    border:10px blue solid;
    box-shadow: 1px 2px 4px rgba(0,0,0,0.5);
    }
</style>
